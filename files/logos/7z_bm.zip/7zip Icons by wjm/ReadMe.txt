Alternate 7-zip Icons and Logos
by Bill Marriott
wjm@wjm.org
8 Nov 05

These icons and images are free artwork; you can redistribute them
and/or modify them under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

The icons and logos are distributed in the hope that they will be useful
and pleasant but WITHOUT WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

USE AT YOUR OWN RISK

Every effort has been made to ensure the quality of these items, 
however, I cannot be responsible for any damage or loss of data that
occurs to your system as a result of the use of these files.

The original logos and icon designs were created with Xara Xtreme.

http://www.xara.com

The icons were created with Axialis Icon Workshop 6.0

http://www.axialis.com

Special thanks to Igor Pavlov, author of 7zip!

http://www.7zip.org